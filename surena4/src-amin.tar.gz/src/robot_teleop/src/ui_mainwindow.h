/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QDoubleSpinBox *NumR1;
    QPushButton *BtnSetPosition;
    QPushButton *BtnStop;
    QLabel *label;
    QDoubleSpinBox *NumR2;
    QLabel *label_2;
    QDoubleSpinBox *NumR3;
    QDoubleSpinBox *NumR4;
    QLabel *label_3;
    QLabel *label_4;
    QDoubleSpinBox *NumR5;
    QDoubleSpinBox *NumR6;
    QLabel *label_5;
    QLabel *label_6;
    QDoubleSpinBox *NumL2;
    QDoubleSpinBox *NumL3;
    QDoubleSpinBox *NumL4;
    QDoubleSpinBox *NumL1;
    QDoubleSpinBox *NumL5;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QDoubleSpinBox *NumL6;
    QLabel *label_12;
    QPushButton *BtnHome;
    QPushButton *BtnActiveAll;
    QPushButton *BtnResetAll;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(558, 408);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        NumR1 = new QDoubleSpinBox(centralWidget);
        NumR1->setObjectName(QStringLiteral("NumR1"));
        NumR1->setGeometry(QRect(136, 8, 69, 26));
        BtnSetPosition = new QPushButton(centralWidget);
        BtnSetPosition->setObjectName(QStringLiteral("BtnSetPosition"));
        BtnSetPosition->setGeometry(QRect(20, 290, 101, 51));
        BtnStop = new QPushButton(centralWidget);
        BtnStop->setObjectName(QStringLiteral("BtnStop"));
        BtnStop->setGeometry(QRect(130, 290, 61, 51));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 10, 111, 20));
        NumR2 = new QDoubleSpinBox(centralWidget);
        NumR2->setObjectName(QStringLiteral("NumR2"));
        NumR2->setGeometry(QRect(136, 40, 69, 26));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(15, 43, 121, 20));
        NumR3 = new QDoubleSpinBox(centralWidget);
        NumR3->setObjectName(QStringLiteral("NumR3"));
        NumR3->setGeometry(QRect(137, 70, 69, 26));
        NumR4 = new QDoubleSpinBox(centralWidget);
        NumR4->setObjectName(QStringLiteral("NumR4"));
        NumR4->setGeometry(QRect(137, 100, 69, 26));
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(28, 103, 101, 20));
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(19, 72, 111, 20));
        NumR5 = new QDoubleSpinBox(centralWidget);
        NumR5->setObjectName(QStringLiteral("NumR5"));
        NumR5->setGeometry(QRect(137, 130, 69, 26));
        NumR6 = new QDoubleSpinBox(centralWidget);
        NumR6->setObjectName(QStringLiteral("NumR6"));
        NumR6->setGeometry(QRect(137, 163, 69, 26));
        label_5 = new QLabel(centralWidget);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(32, 165, 101, 20));
        label_6 = new QLabel(centralWidget);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(37, 132, 91, 20));
        NumL2 = new QDoubleSpinBox(centralWidget);
        NumL2->setObjectName(QStringLiteral("NumL2"));
        NumL2->setGeometry(QRect(447, 38, 69, 26));
        NumL3 = new QDoubleSpinBox(centralWidget);
        NumL3->setObjectName(QStringLiteral("NumL3"));
        NumL3->setGeometry(QRect(448, 68, 69, 26));
        NumL4 = new QDoubleSpinBox(centralWidget);
        NumL4->setObjectName(QStringLiteral("NumL4"));
        NumL4->setGeometry(QRect(448, 98, 69, 26));
        NumL1 = new QDoubleSpinBox(centralWidget);
        NumL1->setObjectName(QStringLiteral("NumL1"));
        NumL1->setGeometry(QRect(447, 6, 69, 26));
        NumL5 = new QDoubleSpinBox(centralWidget);
        NumL5->setObjectName(QStringLiteral("NumL5"));
        NumL5->setGeometry(QRect(448, 128, 69, 26));
        label_7 = new QLabel(centralWidget);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(331, 8, 111, 20));
        label_8 = new QLabel(centralWidget);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(348, 130, 91, 20));
        label_9 = new QLabel(centralWidget);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(343, 162, 101, 20));
        label_10 = new QLabel(centralWidget);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(339, 101, 101, 20));
        label_11 = new QLabel(centralWidget);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(326, 41, 121, 20));
        NumL6 = new QDoubleSpinBox(centralWidget);
        NumL6->setObjectName(QStringLiteral("NumL6"));
        NumL6->setGeometry(QRect(448, 161, 69, 26));
        label_12 = new QLabel(centralWidget);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(330, 70, 111, 20));
        BtnHome = new QPushButton(centralWidget);
        BtnHome->setObjectName(QStringLiteral("BtnHome"));
        BtnHome->setGeometry(QRect(210, 290, 89, 51));
        BtnActiveAll = new QPushButton(centralWidget);
        BtnActiveAll->setObjectName(QStringLiteral("BtnActiveAll"));
        BtnActiveAll->setGeometry(QRect(410, 290, 89, 51));
        BtnResetAll = new QPushButton(centralWidget);
        BtnResetAll->setObjectName(QStringLiteral("BtnResetAll"));
        BtnResetAll->setGeometry(QRect(310, 290, 89, 51));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 558, 22));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        BtnSetPosition->setText(QApplication::translate("MainWindow", "Set Position", 0));
        BtnStop->setText(QApplication::translate("MainWindow", "Stop", 0));
        label->setText(QApplication::translate("MainWindow", "Right Ankle Roll", 0));
        label_2->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Right Ankle Pitch</p></body></html>", 0));
        label_3->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Right Hip Pitch</p></body></html>", 0));
        label_4->setText(QApplication::translate("MainWindow", "Right Knee Pitch", 0));
        label_5->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Right Hip Yaw</p></body></html>", 0));
        label_6->setText(QApplication::translate("MainWindow", "Right Hip Roll", 0));
        label_7->setText(QApplication::translate("MainWindow", "Left Ankle Roll", 0));
        label_8->setText(QApplication::translate("MainWindow", "Left Hip Roll", 0));
        label_9->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Left Hip Yaw</p></body></html>", 0));
        label_10->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Left Hip Pitch</p></body></html>", 0));
        label_11->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Left Ankle Pitch</p></body></html>", 0));
        label_12->setText(QApplication::translate("MainWindow", "Left Knee Pitch", 0));
        BtnHome->setText(QApplication::translate("MainWindow", "Home", 0));
        BtnActiveAll->setText(QApplication::translate("MainWindow", "Active All\n"
"Nodes", 0));
        BtnResetAll->setText(QApplication::translate("MainWindow", "Reset All \n"
"Nodes", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
