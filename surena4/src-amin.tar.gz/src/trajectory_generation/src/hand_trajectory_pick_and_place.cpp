#include "ros/ros.h"
#include "std_msgs/String.h"
#include"Eigen/Dense"
#include <vector>
#include <iostream>
#include <QString>
#include <QList>
#include "Robot.h"
//#include"TaskSpace.h"
#include"taskspaceoffline.h"
#include <qmath.h>
#include <cstring>
#include<qdebug.h>
#include <Eigen/Geometry>
#include <cstdlib>
//#include <link.h>
#include "Eigen/eiquadprog.h"
#include "Eigen/Core"
#include "Eigen/Cholesky"
#include "Eigen/LU"
#include<std_msgs/Int32MultiArray.h>
#include<std_msgs/Float32MultiArray.h>
#include<math.h>
#include<sensor_msgs/Imu.h>
#include<std_msgs/Float64.h>
#include "qcgenerator.h"
#include "right_hand.h"

#include<termios.h>
#include "MinimumJerkInterpolation.h"

using namespace  std;
using namespace  Eigen;

ros::Publisher pub1  ;
ros::Publisher pub2  ;
ros::Publisher pub3  ;
ros::Publisher pub4  ;
ros::Publisher pub5  ;
ros::Publisher pub6  ;
ros::Publisher pub7  ;
ros::Publisher pub8  ;
ros::Publisher pub9  ;
ros::Publisher pub10 ;
ros::Publisher pub11 ;
ros::Publisher pub12 ;
ros::Publisher pub13 ;
ros::Publisher pub14 ;
ros::Publisher pub15 ;
ros::Publisher pub16 ;
ros::Publisher pub17 ;
ros::Publisher pub18 ;
ros::Publisher pub19 ;
ros::Publisher pub20 ;
ros::Publisher pub21 ;
ros::Publisher pub22 ;
ros::Publisher pub23 ;
ros::Publisher pub24 ;
ros::Publisher pub25 ;
ros::Publisher pub26 ;
ros::Publisher pub27 ;
ros::Publisher pub28 ;
ros::Publisher pub29 ;
ros::Publisher pub30 ;
ros::Publisher pub31 ;

int getch()
{
  static struct termios oldt, newt;
  tcgetattr( STDIN_FILENO, &oldt);           // save old settings
  newt = oldt;
  newt.c_lflag &= ~(ICANON);                 // disable buffering
  tcsetattr( STDIN_FILENO, TCSANOW, &newt);  // apply new settings

  int c = getchar();  // read character (non-blocking)

  tcsetattr( STDIN_FILENO, TCSANOW, &oldt);  // restore old settings
  return c;
}





void  SendGazebo(vector<double> q){

    std_msgs::Float64 data;
    data.data=q[1];
    pub1.publish(data);
    data.data=q[2];
    pub2.publish(data);
    data.data=q[3];
    pub3.publish(data);
    data.data=q[4];
    pub4.publish(data);
    data.data=q[5];
    pub5.publish(data);
    data.data=q[6];
    pub6.publish(data);
    data.data=q[7];
    pub7.publish(data);
    data.data=q[8];
    pub8.publish(data);
    data.data=q[9];
    pub9.publish(data);
    data.data=q[10];
    pub10.publish(data);
    data.data=q[11];
    pub11.publish(data);
    data.data=q[12];
    pub12.publish(data);
    data.data=q[13];
    pub13.publish(data);
    data.data=q[14];
    pub14.publish(data);
    data.data=q[15];
    pub15.publish(data);
    data.data=q[16];
    pub16.publish(data);
    data.data=q[17];
    pub17.publish(data);
    data.data=q[18];
    pub18.publish(data);
    data.data=q[19];
    pub19.publish(data);
    data.data=q[20];
    pub20.publish(data);
    data.data=q[21];
    pub21.publish(data);
    data.data=q[22];
    pub22.publish(data);
    data.data=q[23];
    pub23.publish(data);
    data.data=q[24];
    pub24.publish(data);
    data.data=q[25];
    pub25.publish(data);
    data.data=q[26];
    pub26.publish(data);
    data.data=q[27];
    pub27.publish(data);
    data.data=q[28];
    pub28.publish(data);
    data.data=q[29];
    pub29.publish(data);
    data.data=q[30];
    pub30.publish(data);
    data.data=q[31];
    pub31.publish(data);

}



int main(int argc, char **argv)
{

    ros::init(argc, argv, "myNode");

    ros::NodeHandle nh;
    ros::Publisher  chatter_pub  = nh.advertise<std_msgs::Int32MultiArray>("jointdata/qc",1000);

    std_msgs::Int32MultiArray msg;
    std_msgs::MultiArrayDimension msg_dim;

    msg_dim.label = "joint_position";
    msg_dim.size = 1;
    msg.layout.dim.clear();
    msg.layout.dim.push_back(msg_dim);



    pub1  = nh.advertise<std_msgs::Float64>("rrbot/joint1_position_controller/command",1000);
    pub2  = nh.advertise<std_msgs::Float64>("rrbot/joint2_position_controller/command",1000);
    pub3  = nh.advertise<std_msgs::Float64>("rrbot/joint3_position_controller/command",1000);
    pub4  = nh.advertise<std_msgs::Float64>("rrbot/joint4_position_controller/command",1000);
    pub5  = nh.advertise<std_msgs::Float64>("rrbot/joint5_position_controller/command",1000);
    pub6  = nh.advertise<std_msgs::Float64>("rrbot/joint6_position_controller/command",1000);
    pub7  = nh.advertise<std_msgs::Float64>("rrbot/joint7_position_controller/command",1000);
    pub8  = nh.advertise<std_msgs::Float64>("rrbot/joint8_position_controller/command",1000);
    pub9  = nh.advertise<std_msgs::Float64>("rrbot/joint9_position_controller/command",1000);
    pub10 = nh.advertise<std_msgs::Float64>("rrbot/joint10_position_controller/command",1000);
    pub11 = nh.advertise<std_msgs::Float64>("rrbot/joint11_position_controller/command",1000);
    pub12 = nh.advertise<std_msgs::Float64>("rrbot/joint12_position_controller/command",1000);
    pub13 = nh.advertise<std_msgs::Float64>("rrbot/joint13_position_controller/command",1000);
    pub14 = nh.advertise<std_msgs::Float64>("rrbot/joint14_position_controller/command",1000);
    pub15 = nh.advertise<std_msgs::Float64>("rrbot/joint15_position_controller/command",1000);
    pub16 = nh.advertise<std_msgs::Float64>("rrbot/joint16_position_controller/command",1000);
    pub17 = nh.advertise<std_msgs::Float64>("rrbot/joint17_position_controller/command",1000);
    pub18 = nh.advertise<std_msgs::Float64>("rrbot/joint18_position_controller/command",1000);
    pub19 = nh.advertise<std_msgs::Float64>("rrbot/joint19_position_controller/command",1000);
    pub20 = nh.advertise<std_msgs::Float64>("rrbot/joint20_position_controller/command",1000);
    pub21 = nh.advertise<std_msgs::Float64>("rrbot/joint21_position_controller/command",1000);
    pub22 = nh.advertise<std_msgs::Float64>("rrbot/joint22_position_controller/command",1000);
    pub23 = nh.advertise<std_msgs::Float64>("rrbot/joint23_position_controller/command",1000);
    pub24 = nh.advertise<std_msgs::Float64>("rrbot/joint24_position_controller/command",1000);
    pub25 = nh.advertise<std_msgs::Float64>("rrbot/joint25_position_controller/command",1000);
    pub26 = nh.advertise<std_msgs::Float64>("rrbot/joint26_position_controller/command",1000);
    pub27 = nh.advertise<std_msgs::Float64>("rrbot/joint27_position_controller/command",1000);
    pub28 = nh.advertise<std_msgs::Float64>("rrbot/joint28_position_controller/command",1000);
    pub29 = nh.advertise<std_msgs::Float64>("rrbot/joint29_position_controller/command",1000);
    pub30 = nh.advertise<std_msgs::Float64>("rrbot/joint30_position_controller/command",1000);
    pub31 = nh.advertise<std_msgs::Float64>("rrbot/joint31_position_controller/command",1000);



    right_hand hand_funcs;

    VectorXd r_target(3);
    VectorXd r_middle_target(3);

    MatrixXd R_target(3,3);


//        r_target<<.5,
//                -0.1,
//                -0.2;

    r_target<<.4,
            0.1,
            -0.15;
  // R_target=hand_funcs.rot(2,-90*M_PI/180,3)*hand_funcs.rot(3,90*M_PI/180,3)*hand_funcs.rot(2,-40*M_PI/180,3);
    r_middle_target<<.3,
            -.0,
            -.3;

R_target=hand_funcs.rot(2,-90*M_PI/180,3)*hand_funcs.rot(1,-10*M_PI/180+atan2(r_target(1),r_target(0)),3);

VectorXd r_deliver(3);

MatrixXd R_deliver(3,3);



    r_deliver<<r_target(0),
            r_target(1)-.2,
            r_target(2)+.1;
            //R_deliver=hand_funcs.rot(2,-90*M_PI/180,3)*hand_funcs.rot(1,-10*M_PI/180+atan2(r_deliver(1),r_deliver(0)),3);
    R_deliver=R_target;



VectorXd q0(7);

q0<<10*M_PI/180,
        -4*M_PI/180,
        0,
        -20*M_PI/180,
        0,
        0,
        0;


double v0=0;
double v_target =.4;
right_hand hand0(q0,r_target,R_target,0,0);
double d0=hand0.dist;
double d=d0;
double d_des=hand0.d_des;
double theta=hand0.theta;
double theta_target=hand0.theta_target;
double sai=hand0.sai;
double sai_target=hand0.sai_target;
double phi=hand0.phi;
double phi_target=hand0.phi_target;

double theta_deliver;
double sai_deliver;
double phi_deliver;

MinimumJerkInterpolation coef_generator;
MatrixXd X_coef_target;
MatrixXd Y_coef_target;
MatrixXd Z_coef_target;
MatrixXd X_coef_deliver;
MatrixXd Y_coef_deliver;
MatrixXd Z_coef_deliver;

MatrixXd t_target(1,3);
MatrixXd t_deliver(1,2);
MatrixXd P_x(1,3);
MatrixXd V_x(1,3);
MatrixXd A_x(1,3);

MatrixXd P_y(1,3);
MatrixXd V_y(1,3);
MatrixXd A_y(1,3);

MatrixXd P_z(1,3);
MatrixXd V_z(1,3);
MatrixXd A_z(1,3);

///timing
/// 0~t1 reach the target
/// t1~t2 rest to grip
/// t2~t3 move to deliver point
/// t3~t4 rest to release
/// t4~t_end go back to home

double t1=2;
double t2=4;
double t3=6;
double t4=8;
double t_end=10;

t_target<<0,t1/2,t1;
P_x<< hand0.r_right_palm(0),r_middle_target(0),r_target(0);
P_y<< hand0.r_right_palm(1),r_middle_target(1),r_target(1);
P_z<< hand0.r_right_palm(2),r_middle_target(2),r_target(2);
V_x<<0,INFINITY,0;
V_y<<0,INFINITY,0;
V_z<<0,INFINITY,0;
A_x<<0,INFINITY,0;
A_y<<0,INFINITY,0;
A_z<<0,INFINITY,0;

X_coef_target=coef_generator.Coefficient(t_target,P_x,V_x,A_x);
Y_coef_target=coef_generator.Coefficient(t_target,P_y,V_y,A_y);
Z_coef_target=coef_generator.Coefficient(t_target,P_z,V_z,A_z);
ROS_INFO("test");
t_deliver<<t2,t3;

P_x.resize(1,2);P_y.resize(1,2);P_z.resize(1,2);
ROS_INFO("test");
P_x<<r_target(0),r_deliver(0);
P_y<<r_target(1),r_deliver(1);
P_z<<r_target(2),r_deliver(2);

V_x.resize(1,2);V_y.resize(1,2);V_z.resize(1,2);
A_x.resize(1,2);A_y.resize(1,2);A_z.resize(1,2);
V_x<<0,0;
V_y<<0,0;
V_z<<0,0;
A_x<<0,0;
A_y<<0,0;
A_z<<0,0;

X_coef_deliver=coef_generator.Coefficient(t_deliver,P_x,V_x,A_x);
Y_coef_deliver=coef_generator.Coefficient(t_deliver,P_y,V_y,A_y);
Z_coef_deliver=coef_generator.Coefficient(t_deliver,P_z,V_z,A_z);







//ROS_INFO("%d,%d",X_coef.rows(),X_coef.cols());
//ROS_INFO("\ncoeff_x=%f\t%f\t%f\t%f\t%f\t%f",X_coef(0)
//ROS_INFO("\n
//ROS_INFO("\




//ROS_INFO("theta_target=%f,sai_target=%f,phi_target=%f",theta_target,sai_target,phi_target);
ROS_INFO("\nr_target=\n%f\n%f\n%f",r_target(0),r_target(1),r_target(2));
ROS_INFO("\nR_target=\n%f\t%f\t%f\n%f\t%f\t%f\n%f\t%f\t%f\n",R_target(0,0),R_target(0,1),R_target(0,2),R_target(1,0),R_target(1,1),R_target(1,2),R_target(2,0),R_target(2,1),R_target(2,2));
ROS_INFO("press any key to start!");
ROS_INFO("q0=[%f,%f,%f,%f,%f,%f,%f]",q0(0),q0(1),q0(2),q0(3),q0(4),q0(5),q0(6));
getch();

QVector<double> qr1;
QVector<double> qr2;
QVector<double> qr3;
QVector<double> qr4;
QVector<double> qr5;
QVector<double> qr6;
QVector<double> qr7;


int i=0;
VectorXd q_ra;
VectorXd qr_end;
q_ra=q0;

qr1.append(q_ra(0));
qr2.append(q_ra(1));
qr3.append(q_ra(2));
qr4.append(q_ra(3));
qr5.append(q_ra(4));
qr6.append(q_ra(5));
qr7.append(q_ra(6));


vector<double> q_init(31);
for (int i = 0; i < 31; ++i) {
    q_init[i]=0;
}
q_init[15]=qr1[0];
q_init[16]=qr2[0];
q_init[17]=qr3[0];
q_init[18]=qr4[0];
q_init[19]=qr5[0];
q_init[20]=qr6[0];
q_init[21]=qr7[0];


SendGazebo(q_init);



int q_motor[8];
for (int var = 0; var < 8; ++var) {
    q_motor[var]=0;
}

vector<double> q(31);


ros::Rate loop_rate(200);
int count = 1;
double time;
//int endofdeliver;
//bool getting_back=false;


    while (ros::ok())
    {
     time=double(count)*.005;
     VectorXd P(3);
     VectorXd V(3);
if(time<t_target(1))
{
    P<<coef_generator.GetAccVelPos(X_coef_target.row(0),time,0,5)(0,0),
       coef_generator.GetAccVelPos(Y_coef_target.row(0),time,0,5)(0,0),
       coef_generator.GetAccVelPos(Z_coef_target.row(0),time,0,5)(0,0);


    V<<coef_generator.GetAccVelPos(X_coef_target.row(0),time,0,5)(0,1),
       coef_generator.GetAccVelPos(Y_coef_target.row(0),time,0,5)(0,1),
       coef_generator.GetAccVelPos(Z_coef_target.row(0),time,0,5)(0,1);
    right_hand hand(q_ra,V,r_target,R_target);
    hand.doQP(q_ra);
    q_ra=hand.q_next;
    d=hand.dist;
    theta=hand.theta;
    sai=hand.sai;
    phi=hand.phi;
  }

if(time>=t_target(1) && time<t_target(2))
{
    P<<coef_generator.GetAccVelPos(X_coef_target.row(1),time,t_target(1),5)(0,0),
       coef_generator.GetAccVelPos(Y_coef_target.row(1),time,t_target(1),5)(0,0),
       coef_generator.GetAccVelPos(Z_coef_target.row(1),time,t_target(1),5)(0,0);


    V<<coef_generator.GetAccVelPos(X_coef_target.row(1),time,t_target(1),5)(0,1),
       coef_generator.GetAccVelPos(Y_coef_target.row(1),time,t_target(1),5)(0,1),
       coef_generator.GetAccVelPos(Z_coef_target.row(1),time,t_target(1),5)(0,1);
    right_hand hand(q_ra,V,r_target,R_target);
    hand.doQP(q_ra);
    q_ra=hand.q_next;
    d=hand.dist;
    theta=hand.theta;
    sai=hand.sai;
    phi=hand.phi;
  }
if(time>=t_deliver(0) && time<t_deliver(1))
{
    P<<coef_generator.GetAccVelPos(X_coef_deliver.row(0),time,t_deliver(0),5)(0,0),
       coef_generator.GetAccVelPos(Y_coef_deliver.row(0),time,t_deliver(0),5)(0,0),
       coef_generator.GetAccVelPos(Z_coef_deliver.row(0),time,t_deliver(0),5)(0,0);


    V<<coef_generator.GetAccVelPos(X_coef_deliver.row(0),time,t_deliver(0),5)(0,1),
       coef_generator.GetAccVelPos(Y_coef_deliver.row(0),time,t_deliver(0),5)(0,1),
       coef_generator.GetAccVelPos(Z_coef_deliver.row(0),time,t_deliver(0),5)(0,1);

    right_hand hand(q_ra,V,r_target,R_target);
    hand.doQP(q_ra);
    q_ra=hand.q_next;
    d=hand.dist;
    theta=hand.theta;
    sai=hand.sai;
    phi=hand.phi;



    qr_end=q_ra;



}



if(time>=t4 && time<t_end)
{
    MatrixXd t_r(1,2);
    MatrixXd p_r(7,2);
    MatrixXd z_r(1,2);
    MatrixXd r_coeff;
    t_r<<t4,t_end;
    z_r<<0,0;

    p_r<<qr_end(0),10*M_PI/180,
            qr_end(1),-4*M_PI/180,
            qr_end(2),0,
            qr_end(3),-20*M_PI/180,
            qr_end(4),0,
            qr_end(5),0,
            qr_end(6),0;

    for (int i = 0; i < 7; ++i) {
        r_coeff=coef_generator.Coefficient(t_r,p_r.row(i),z_r,z_r);
        q_ra(i)=coef_generator.GetAccVelPos(r_coeff.row(0),time,t_r(0) ,5)(0,0);

    }
}

if(time>=t_end){break;}


ROS_INFO("time=%f",time);


        qr1.append(q_ra(0));
        qr2.append(q_ra(1));
        qr3.append(q_ra(2));
        qr4.append(q_ra(3));
        qr5.append(q_ra(4));
        qr6.append(q_ra(5));
        qr7.append(q_ra(6));

count=qr1.size()-1;

        i++;

//        else{
//            ROS_INFO("reached to target!");
//            reaching=false;
//        delivering=true;
//        right_hand hand(q_ra,r_deliver,R_deliver,0,0);
//        double d0=hand0.dist;
//         d=d0;
//                    theta_deliver=hand.theta_target;
//                 sai_deliver=hand.sai_target;
//                 phi_deliver=hand.phi_target;
//                 i=0;


//        }
//}

//if(delivering){

//    if ((d>d_des)   || (abs(theta-theta_deliver)>.02)   || (abs(sai-sai_deliver)>.02)  || (abs(phi-phi_deliver)>.02)  )
//{


//    right_hand hand(q_ra,r_deliver,R_deliver,i,d0);


//    hand.doQP(q_ra);
//    q_ra=hand.q_next;

//    qr1.append(q_ra(0));
//    qr2.append(q_ra(1));
//    qr3.append(q_ra(2));
//    qr4.append(q_ra(3));
//    qr5.append(q_ra(4));
//    qr6.append(q_ra(5));
//    qr7.append(q_ra(6));

//count=qr1.size()-1;
//    d=hand.dist;
//    theta=hand.theta;
//    sai=hand.sai;
//    phi=hand.phi;

//    i++;
//    ROS_INFO("x=%f\ty=%f\tz=%f\t",hand.r_right_palm(0),hand.r_right_palm(1),hand.r_right_palm(2));

//    }

//    else{
//ROS_INFO("delivered the object!");
//    delivering=false;

//    getting_back=true;
//  endofdeliver=count;

//    }

//}
// if(getting_back && (abs(q_ra(0)-q0(0))>.0001)){

//    q_ra(0)+=(q0(0)-qr1[endofdeliver])/5*hand0.T;
//    q_ra(1)+=(q0(1)-qr2[endofdeliver])/5*hand0.T;
//    q_ra(2)+=(q0(2)-qr3[endofdeliver])/5*hand0.T;
//    q_ra(3)+=(q0(3)-qr4[endofdeliver])/5*hand0.T;
//    q_ra(4)+=(q0(4)-qr5[endofdeliver])/5*hand0.T;
//    q_ra(5)+=(q0(5)-qr6[endofdeliver])/5*hand0.T;
//    q_ra(6)+=(q0(6)-qr7[endofdeliver])/5*hand0.T;


//    qr1.append(q_ra(0));
//    qr2.append(q_ra(1));
//    qr3.append(q_ra(2));
//    qr4.append(q_ra(3));
//    qr5.append(q_ra(4));
//    qr6.append(q_ra(5));
//    qr7.append(q_ra(6));
//    count=qr1.size()-1;
//}







        for (int i = 0; i < 31; ++i) {
            q[i]=0;
        }


        q[15]=qr1[count];
        q[16]=qr2[count];
        q[17]=qr3[count];
        q[18]=qr4[count];

        q[19]=qr5[count];
        q[20]=qr6[count];
        q[21]=qr7[count];

//       ROS_INFO("q1=%f\tq2=%f\tq3=%f\tq4=%f\tq5=%f\tq6=%f\tq7=%f\t",180/M_PI*q[15],180/M_PI*q[16],180/M_PI*q[17],180/M_PI*q[18],180/M_PI*q[19],180/M_PI*q[20],180/M_PI*q[21]);
//       ROS_INFO("x=%f\ty=%f\tz=%f\t",hand.r_right_palm(0),hand.r_right_palm(1),hand.r_right_palm(2));
        SendGazebo(q);



       msg.data.clear();

      for(int  i = 0;i < 12;i++)
      {
          msg.data.push_back(0);
      }

      q_motor[0]=-int(6*(qr1[count]-q0(0))*360/M_PI);
      q_motor[1]=int(6*(qr2[count]-q0(1))*360/M_PI);
      q_motor[2]=-int(6*(qr3[count]-q0(2))*300/M_PI);
      q_motor[3]=int(6*(qr4[count]-q0(3))*300/M_PI);

      //right hand epose
      msg.data.push_back(q_motor[0]);//12 -y  a,z
      msg.data.push_back(q_motor[1]);//13 +x
      msg.data.push_back(q_motor[2]);//14 -z
      msg.data.push_back(q_motor[3]);//15 +y
      //right hand dynamixel + fingers
      msg.data.push_back(0);//16
      msg.data.push_back(0);//17
      msg.data.push_back(0);//18
      msg.data.push_back(0);//19
      //left hand epose
      msg.data.push_back(q_motor[4]);//20 +y
      msg.data.push_back(q_motor[5]);//21 +x
      msg.data.push_back(q_motor[6]);//22 -z
      msg.data.push_back(q_motor[7]);//23 -y
      //left hand dynamixel + fingers
      msg.data.push_back(0);//24
      msg.data.push_back(0);//25
      msg.data.push_back(0);//26
      msg.data.push_back(0);//27

        chatter_pub.publish(msg);


        ros::spinOnce();
        loop_rate.sleep();

}




    return 0;
}
