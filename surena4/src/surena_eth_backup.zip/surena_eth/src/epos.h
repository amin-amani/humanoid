#ifndef EPOS_H
#define EPOS_H

#include <QObject>
#include <QDebug>
#include <qthread.h>
#include <qlist.h>
#include "can.h"
#include "pingmodel.h"
#include "ethernetpackets.h"
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/MagneticField.h>
#include <geometry_msgs/Accel.h>
#include <geometry_msgs/Wrench.h>
#include <tf2/LinearMath/Quaternion.h>

//#include "tcphandler.h"
#define USE_NET

enum EPOSErrors { OK=0,USB_ERROR, BOARD_ERROR, CAN_ERROR,SDO_REJECT,SDO_BAD_REPLAY,NO_ANSER,NETWOR_ERROR,EPOS_ERROR};
enum EPOSOperationMode {PPM=1,PVM=3,HMM=6,CSP=8,CST=10};

class Epos : public QObject
{
Q_OBJECT

const double m_dDecouplingCoefficient [6][6]={
{1,0,0,0,0,0},
{0,1,0,0,0,0},
{0,0,1,0,0,0},
{0,0,0,1,0,0},
{0,0,0,0,1,0},
{0,0,0,0,0,1},



//{1033.78406318488,0,0,0,0,0},
//{0,1037.08620260516,0,0,0,0},
//{0,0,7022.47191011235,0,0,0},
//{0,0,0,92.2339051835454,0,0},
//{0,0,0,0,92.6698174404596,0},
//{0,0,0,0,0,60.819851599562},
};
const double sensitivityFTRight[6]=  // #573 Right foot FTsensor
{
    9.6732*0.0001,
    9.6424*0.0001,
    1.4240*0.0001,
    1.0842*0.01,
    1.0791*0.01,
    1.6442*0.01
};
 const double sensitivityFTLeft[6]= // #574 Left foot FTsensor
{
    9.5469*0.0001,
    9.6402*0.0001,
    1.4234*0.0001,
    1.0638*0.01,
    1.0505*0.01,
    1.6489*0.01
};
 const double offsetFTRight[6]= // #573 Right foot FTsensor
{
32767,
//{32703},
32625,
//{32720},
32655,
//{32689},
32585,
//{32639},
32750,
//{32663},
32550
};
 const double offsetFTLeft[6]= // #574 Left foot FTsensor
{
//{32689},
32660,
//{32762},
32775,
//{32761},
32785,
//{32691},
32780,
//{32749},
32675,
//{32739},
32700
};
 const double gainFTRight[6]= // #573 Right foot FTsensor
{
    123.3246,
    123.3079,
    123.3880,
    123.4881,
    123.5682,
    123.3213
};
 const double gainFTLeft[6]= // #574 Left foot FTsensor
{
    123.5760,
    123.5726,
    123.5427,
    123.5660,
    123.5992,
    123.4928
};
 const double ExFTRight[6]= // #573 Right foot FTsensor
{
    4.971,
    4.971,
    4.971,
    4.971,
    4.971,
    4.971
};
 const double ExFTLeft[6]= // #574 Left foot FTsensor
{
    4.9846,
    4.9846,
    4.9846,
    4.9846,
    4.9846,
    4.9846
};

TcpHandler tcp;
int flag_sensor_pa=0;

uint16_t bump_sensor_left[4];
uint16_t bump_sensor_right[4];

QList<uint16_t> bump_sensor_list;
QList<int32_t> positions;
QList<int32_t> positionsInc;
QList<int16_t> ft;
QList<float> imu_data_list;


IMUReceivedPacketType *ImuPacket;
EthernetReceivedPacketType *incommingPacket;
BumpSensorPacket *bumpPacket;
void CheckCanBoardRequest();
QByteArray LastPacketreceived;
public:
sensor_msgs::Imu IMU;
sensor_msgs::MagneticField MagneticSensor;
geometry_msgs::Accel Acceleration;
geometry_msgs::Wrench ForceTorqSensorRight,ForceTorqSensorLeft;
    PingModel ping;
	Can can;
    explicit Epos(QObject *parent = 0);
/// use -1 for infinit wait
    EPOSErrors Init(int tryCount);
    EPOSErrors EnableDevice(int devID,EPOSOperationMode mode);
    void SetPreoperationalMode(int devID);
    void ResetComunication(int devID);
    void StartNode(int devID);
    void SetMode(int devID, EPOSOperationMode mode);
    void StopNode(int devID);
    void SwitchOn(int devID);
    void SwitchOff(int devID);
    EPOSErrors ResetNode(int devID);
    unsigned char GetSDOCODE(int len);
    EPOSErrors SDOWriteCommand(int id, unsigned long input, int index, unsigned char sub_index, unsigned char len, char devID);
    void SDOReadCommand(int id, int index, unsigned char subIndex, char devID);
    EPOSErrors ReadRegisterValue(int index, int subIndex, int canID, int devID, int32_t &value, int timeout);
    EPOSErrors ReadRegister(int index, int subIndex, int canID, int devID, int32_t &value, int timeout, int trycount);
    EPOSErrors WriteRegister(int index, int subIndex, int canID, int devID, int32_t value, int len=4);

    EPOSErrors ActivePPM(int canID, int devId);
    bool SetPosition(int canID, int devId, int position, int velocity);
    QString ReadCurrentError(int canID, int devID);
	
    EPOSErrors test_arya(int devID) ;

    bool ActiveCSP(int nodeID);
    bool AllActiveCSP();

    // bool ResetAllNodes();
    // void SetPreoperationalMode();
    // void StartNode();
    // void SetMode(unsigned char mode);
    // void SwitchOff();
    // void SwitchOn();
    // void ActiveCST();
    // void ActivePPM();
    // void SetMode(ModesOfOperations mode);
    // void MoveToTarget();
    // void MoveToTargetPDO();
    // void SetPositionSDO(long position, long velocity);
    // void DisconnectTCP();
        void SetPositionCST(int position, int velocity);
        void SetAllPositionCST(QList<int> all_position, int motor_num);
        void can_write(unsigned char motor_index,unsigned int can_id, unsigned char* data_buff);
        void can_read_test(unsigned char motor_index);

        void WaitMs(int ms);
        QByteArray EposReceiveData();

        bool StartFeedBack();
        bool ActiveAllCSP();


        float QByteArrayToFloat(QByteArray arr);
        EPOSErrors ReadAllRegisters(int index, int subIndex, int canID, QList<int32_t> &value, int timeout);
        bool CheckZynq();
signals:

    void NewDataReady();
    void Dummy();
  void  FeedBackReceived(QList<int16_t> ft, QList<int32_t> positions,QList<int32_t> positionsInc,QList<uint16_t> bump_sensor_list,QList<float> imu_data_list);


public slots:


    void DataReceived(QByteArray data);

};



#endif // EPOS_H
